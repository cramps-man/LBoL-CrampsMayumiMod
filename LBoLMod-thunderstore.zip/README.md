## this mod is still a work in progress
 - there is only a single default card image
 - there are no attack animations
 - most buff icons have no image
 - exhibits and spell cards have no icon
 - most names are placeholder
In spite of this, the mod is fully playable with <blah> cards (still not quite complete)

## Char overview
## Credits
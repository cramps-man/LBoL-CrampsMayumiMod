## 0.1.1

### Fixes

- If you swap your exhibit as Mayumi, you will still get your starting Haniwa per battle
- Fix starting power being 30 instead of 0

### Text adjustments

- Adjust text for Permanent Assign to say "up to 2" when upgraded
- Adjusted cases where the word "hp" was used instead of "life" (Cavalry Rush and Charge Attack)
- Adjusted Cavalry Rush to be more clear for when mana can be gained

### Other

- Adjusted complexity rating for both decks to be 3

## 0.1.0

Initial version